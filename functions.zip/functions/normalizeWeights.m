function [Wn] = normalizeWeights(W)
%Normalize weights and remove values from outside the [0-1] range
N = size(W,3);
Wn = uint8(W*255);
Wn = double(Wn)/255;
Wn = Wn + 1E-12;
Wn = Wn./repmat(sum(Wn,3),[1 1 N]);
end