% contrast measure


function C = weight_contrast(I)
  %h = [0 1 0; 1 -4 1; 0 1 0]; % laplacian filter
  N = size(I,4);
  C = zeros(size(I,1),size(I,2),N);
  h = fspecial('Laplacian',0);
  
  for i = 1:N
    mono = rgb2gray(I(:,:,:,i));
    C(:,:,i) = abs(imfilter(mono,h,'replicate'));
  end
end